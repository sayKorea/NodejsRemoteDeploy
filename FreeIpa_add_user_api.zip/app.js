
const ipa = require('node-freeipa')

const opts = {
    server: "auth.datanuri.co.kr",
    auth: {
        user: "admin",
        pass: "admin.123"
    },
    expires: 15
};

ipa.configure(opts);
try{
ipa.user_add([], {
  uid: "datanuritest55",
  givenname: "datanuritest1",
  sn: "co",
  cn: "kr",
  mail: "datanuritest1@a.c",
  userpassword: "datanuritest1",
  setattr: 'krbpasswordexpiration=20990101010101Z'
  }).then(result =>{
  console.log(result);
});
}catch (error) {
    console.log('Task Failure', error);
}
ipa.user_find().then(result => {
  console.log(result);
});
